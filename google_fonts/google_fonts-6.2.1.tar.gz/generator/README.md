Generates the `GoogleFonts` class, list of supported families, and updates CHANGELOG.md and pubspec.yaml.

1. Navigate to the root directory of this project.
2. `dart pub global activate cider`
3. `dart generator/generator.dart`
